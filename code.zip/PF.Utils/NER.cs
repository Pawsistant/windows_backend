﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PF.Utils
{
    public class NER
    {
        public static async Task<Dictionary<String, List<String>>> Parse(string text)
        {
            //TODO: Implement
            return null;
        }
    }
}
